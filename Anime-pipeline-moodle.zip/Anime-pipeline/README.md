# Anime Genre Prediction Pipeline

## Team Members

- Name: youssef hassan younis,  ID:231001243
- Name: khaled mohamed yehia, ID: 231001055

## Dataset

`top_anime_dataset.csv` contains around 17,000 anime titles from MyAnimeList with metadata such as `type`, `score`, `synopsis`, and multi-label `genres`.

The project builds an end-to-end NLP pipeline that cleans the raw CSV, engineers features, trains a multi-label genre classifier, and generates plots and cluster summaries.

## Project Layout

```text
customer-analytics/
|-- Dockerfile
|-- ingest.py
|-- preprocess.py
|-- analytics.py
|-- visualize.py
|-- cluster.py
|-- pipeline_utils.py
|-- summary.sh
|-- README.md
|-- top_anime_dataset.csv
`-- results/
```

## How to Run

Build the image:

```bash
cd customer-analytics
docker build -t anime-pipeline .
```

Run the container:

```bash
docker run -it -v $(pwd)/results:/app/pipeline/results --name anime-run anime-pipeline
```

Inside the container, run the pipeline:

```bash
python ingest.py top_anime_dataset.csv
```

After the pipeline finishes, copy outputs to the host and stop the container:

```bash
bash summary.sh
```

## Execution Flow

```text
top_anime_dataset.csv
  -> ingest.py
  -> preprocess.py
  -> analytics.py
  -> visualize.py
  -> cluster.py
  -> results files
```

## Generated Outputs

- `data_raw.csv`
- `data_preprocessed.csv`
- `insight1.txt`
- `insight2.txt`
- `insight3.txt`
- `summary_plot.png`
- `clusters.txt`

## Screenshots To Add

Replace these placeholders with screenshots from your run:

- Terminal output during the pipeline run
- `summary_plot.png`
- A snippet from `insight3.txt`
- `clusters.txt` contents

## Notes

- `preprocess.py` drops leakage-prone `rank`, removes rows without `synopsis`, cleans genre labels, encodes categoricals, scales numeric features, bins score/year, and creates TF-IDF features.
- `analytics.py` trains a `OneVsRestClassifier(LogisticRegression)` on synopsis text and reports micro/macro F1 plus per-genre scores.
- `cluster.py` runs `KMeans(n_clusters=4)` on `score`, `members`, `favorites`, `popularity`, and `episodes`.
