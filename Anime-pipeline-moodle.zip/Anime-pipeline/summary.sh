#!/bin/bash

set -euo pipefail

CONTAINER_NAME="anime-run"
HOST_DIR="./results"

mkdir -p "$HOST_DIR"

docker cp "$CONTAINER_NAME":/app/pipeline/data_raw.csv "$HOST_DIR/"
docker cp "$CONTAINER_NAME":/app/pipeline/data_preprocessed.csv "$HOST_DIR/"
docker cp "$CONTAINER_NAME":/app/pipeline/insight1.txt "$HOST_DIR/"
docker cp "$CONTAINER_NAME":/app/pipeline/insight2.txt "$HOST_DIR/"
docker cp "$CONTAINER_NAME":/app/pipeline/insight3.txt "$HOST_DIR/"
docker cp "$CONTAINER_NAME":/app/pipeline/summary_plot.png "$HOST_DIR/"
docker cp "$CONTAINER_NAME":/app/pipeline/clusters.txt "$HOST_DIR/"

echo "[summary] All outputs copied to $HOST_DIR"

docker stop "$CONTAINER_NAME"
docker rm "$CONTAINER_NAME"
echo "[summary] Container stopped and removed."
