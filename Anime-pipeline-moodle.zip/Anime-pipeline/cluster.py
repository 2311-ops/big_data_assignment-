from __future__ import annotations

import sys

import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

from pipeline_utils import save_text


def main() -> None:
    input_path = sys.argv[1] if len(sys.argv) > 1 else "data_preprocessed.csv"
    df = pd.read_csv(input_path)

    features = [col for col in ["score", "members", "favorites", "popularity", "episodes"] if col in df.columns]
    if len(features) < 2:
        raise SystemExit("Not enough numeric columns for clustering.")

    X = df[features].apply(pd.to_numeric, errors="coerce").fillna(0.0)
    X_scaled = StandardScaler().fit_transform(X)

    km = KMeans(n_clusters=4, random_state=42, n_init=10)
    labels = km.fit_predict(X_scaled)
    counts = pd.Series(labels).value_counts().sort_index()

    centers = pd.DataFrame(km.cluster_centers_, columns=features)
    lines = ["K-Means cluster summary:"]
    for cluster_id, count in counts.items():
        center = centers.loc[cluster_id]
        descriptor = (
            f"score={center['score']:.2f}, members={center['members']:.2f}, "
            f"favorites={center['favorites']:.2f}, popularity={center['popularity']:.2f}, "
            f"episodes={center['episodes']:.2f}"
        )
        lines.append(f"- Cluster {cluster_id}: {count:,} samples | centroid z-scores -> {descriptor}")

    save_text("clusters.txt", "\n".join(lines) + "\n")
    print("[cluster] Saved clusters.txt", flush=True)


if __name__ == "__main__":
    main()
