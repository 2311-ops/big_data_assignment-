from __future__ import annotations

import subprocess
import sys

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

from pipeline_utils import normalize_genre_list, save_figure


def main() -> None:
    input_path = sys.argv[1] if len(sys.argv) > 1 else "data_preprocessed.csv"
    df = pd.read_csv(input_path)

    genre_counts = df["genres"].map(normalize_genre_list).explode().value_counts().head(15)
    score_by_type = df[["type", "score"]].dropna()
    numeric_cols = [col for col in ["score", "members", "favorites", "popularity", "episodes"] if col in df.columns]
    corr_df = df[numeric_cols].apply(pd.to_numeric, errors="coerce").corr() if numeric_cols else pd.DataFrame()

    sns.set_theme(style="whitegrid")
    fig, axes = plt.subplots(1, 3, figsize=(18, 6))

    if not genre_counts.empty:
        axes[0].barh(genre_counts.index[::-1], genre_counts.values[::-1], color="#4c78a8")
        axes[0].set_title("Top 15 Genre Frequencies")
        axes[0].set_xlabel("Title Count")
        axes[0].set_ylabel("Genre")
    else:
        axes[0].set_axis_off()

    if not score_by_type.empty:
        order = score_by_type.groupby("type")["score"].median().sort_values().index
        sns.boxplot(data=score_by_type, x="score", y="type", order=order, ax=axes[1], color="#f58518")
        axes[1].set_title("Score Distribution by Anime Type")
        axes[1].set_xlabel("Score")
        axes[1].set_ylabel("Type")
    else:
        axes[1].set_axis_off()

    if not corr_df.empty:
        sns.heatmap(corr_df, annot=True, cmap="coolwarm", center=0, ax=axes[2])
        axes[2].set_title("Engagement Feature Correlation")
    else:
        axes[2].set_axis_off()

    plt.tight_layout()
    save_figure(fig, "summary_plot.png")
    plt.close(fig)
    print("[visualize] Saved summary_plot.png", flush=True)
    subprocess.run([sys.executable, "cluster.py", "data_preprocessed.csv"], check=True)


if __name__ == "__main__":
    main()
