from __future__ import annotations

import subprocess
import sys
from collections import Counter

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    f1_score,
    hamming_loss,
    classification_report,
)
from sklearn.model_selection import train_test_split
from sklearn.multiclass import OneVsRestClassifier

from pipeline_utils import normalize_genre_list, save_text


def genre_columns(df: pd.DataFrame) -> list[str]:
    cols = [col for col in df.columns if col.startswith("genre_")]
    if cols:
        return cols
    return []


def main() -> None:
    input_path = sys.argv[1] if len(sys.argv) > 1 else "data_preprocessed.csv"
    df = pd.read_csv(input_path)

    if "genres" not in df.columns or "score" not in df.columns:
        raise SystemExit("Expected columns 'genres' and 'score' in data_preprocessed.csv")

    genre_lists = df["genres"].map(normalize_genre_list)
    genre_counter = Counter(genre for genres in genre_lists for genre in genres)
    total_rows = len(df)

    top_genres = genre_counter.most_common(10)
    lines = ["Top 10 genres by title count:"]
    for genre, count in top_genres:
        pct = (count / total_rows) * 100 if total_rows else 0
        lines.append(f"- {genre}: {count:,} titles ({pct:.1f}% of dataset)")
    save_text("insight1.txt", "\n".join(lines) + "\n")

    score_by_genre: list[tuple[str, float, int]] = []
    for genre in sorted(genre_counter):
        mask = genre_lists.map(lambda items, g=genre: g in items)
        if mask.any():
            score_by_genre.append((genre, float(df.loc[mask, "score"].mean()), int(mask.sum())))
    score_by_genre.sort(key=lambda item: item[1], reverse=True)

    lines = ["Average score by genre:"]
    for genre, avg_score, count in score_by_genre[:10]:
        lines.append(f"- {genre}: average score {avg_score:.2f} across {count:,} titles")
    if score_by_genre:
        best = score_by_genre[0]
        worst = min(score_by_genre, key=lambda item: item[1])
        lines.append("")
        lines.append(f"Highest average score: {best[0]} ({best[1]:.2f})")
        lines.append(f"Lowest average score: {worst[0]} ({worst[1]:.2f})")
    save_text("insight2.txt", "\n".join(lines) + "\n")

    genre_target_cols = [col for col in df.columns if col.startswith("genre_")]
    if genre_target_cols:
        y = df[genre_target_cols].astype(int)
        label_names = [col.replace("genre_", "", 1) for col in genre_target_cols]
    else:
        from sklearn.preprocessing import MultiLabelBinarizer

        mlb = MultiLabelBinarizer()
        y = pd.DataFrame(mlb.fit_transform(genre_lists), columns=mlb.classes_)
        label_names = list(mlb.classes_)

    support = y.sum(axis=0)
    keep_mask = support >= 50
    if keep_mask.sum() == 0:
        keep_mask = support > 0
    y = y.loc[:, keep_mask]
    label_names = [label for label, keep in zip(label_names, keep_mask) if keep]

    text_source = df["synopsis"].fillna("").astype(str)
    X_train, X_test, y_train, y_test = train_test_split(
        text_source,
        y,
        test_size=0.2,
        random_state=42,
    )

    vectorizer = TfidfVectorizer(max_features=500, ngram_range=(1, 2))
    X_train_vec = vectorizer.fit_transform(X_train)
    X_test_vec = vectorizer.transform(X_test)

    model = OneVsRestClassifier(
        LogisticRegression(
            max_iter=1000,
            class_weight="balanced",
            solver="liblinear",
        )
    )
    model.fit(X_train_vec, y_train)
    y_pred = model.predict(X_test_vec)

    micro_f1 = f1_score(y_test, y_pred, average="micro", zero_division=0)
    macro_f1 = f1_score(y_test, y_pred, average="macro", zero_division=0)
    ham_loss = hamming_loss(y_test, y_pred)

    per_genre = []
    for idx, label in enumerate(label_names):
        score = f1_score(y_test.iloc[:, idx], y_pred[:, idx], zero_division=0)
        per_genre.append((label, score))
    per_genre.sort(key=lambda item: item[1], reverse=True)

    lines = [
        "NLP model performance:",
        f"- TF-IDF features: {X_train_vec.shape[1]:,}",
        f"- Labels used: {len(label_names):,}",
        f"- Micro F1: {micro_f1:.3f}",
        f"- Macro F1: {macro_f1:.3f}",
        f"- Hamming loss: {ham_loss:.3f}",
        "",
        "Best predicted genres:",
    ]
    for label, score in per_genre[:5]:
        lines.append(f"- {label}: F1={score:.3f}")
    lines.append("")
    lines.append("Hardest predicted genres:")
    for label, score in per_genre[-5:][::-1]:
        lines.append(f"- {label}: F1={score:.3f}")
    lines.append("")
    lines.append("Per-genre classification report:")
    report = classification_report(y_test, y_pred, target_names=label_names, zero_division=0)
    lines.append(report)
    save_text("insight3.txt", "\n".join(lines) + "\n")

    print(
        f"[analytics] Micro F1={micro_f1:.3f}, Macro F1={macro_f1:.3f}, Hamming Loss={ham_loss:.3f}",
        flush=True,
    )
    subprocess.run([sys.executable, "visualize.py", "data_preprocessed.csv"], check=True)


if __name__ == "__main__":
    main()
