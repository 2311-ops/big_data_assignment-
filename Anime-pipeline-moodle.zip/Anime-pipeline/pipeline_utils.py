from __future__ import annotations

import re
import shutil
from pathlib import Path
from typing import Iterable

import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parent
RESULTS_DIR = PROJECT_ROOT / "results"


def ensure_results_dir() -> None:
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)


def project_path(*parts: str) -> Path:
    return PROJECT_ROOT.joinpath(*parts)


def save_text(filename: str, content: str) -> Path:
    ensure_results_dir()
    path = PROJECT_ROOT / filename
    path.write_text(content, encoding="utf-8")
    shutil.copy2(path, RESULTS_DIR / filename)
    return path


def save_dataframe(df: pd.DataFrame, filename: str) -> Path:
    ensure_results_dir()
    path = PROJECT_ROOT / filename
    df.to_csv(path, index=False)
    shutil.copy2(path, RESULTS_DIR / filename)
    return path


def save_figure(fig, filename: str, dpi: int = 150) -> Path:
    ensure_results_dir()
    path = PROJECT_ROOT / filename
    fig.savefig(path, dpi=dpi, bbox_inches="tight")
    shutil.copy2(path, RESULTS_DIR / filename)
    return path


def clean_text(value: object, stop_words: set[str]) -> str:
    if pd.isna(value):
        return ""
    text = str(value).lower()
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    tokens = [token for token in text.split() if token not in stop_words]
    return " ".join(tokens)


def normalize_genre_list(value: object) -> list[str]:
    if pd.isna(value):
        return []
    genres = [item.strip() for item in str(value).split(",")]
    return [item for item in genres if item]


def normalize_bool(value: object) -> bool:
    if isinstance(value, bool):
        return value
    if pd.isna(value):
        return False
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return bool(value)
    text = str(value).strip().lower()
    if text in {"true", "1", "yes", "y", "t"}:
        return True
    if text in {"false", "0", "no", "n", "f"}:
        return False
    return bool(text)


def safe_numeric(series: pd.Series) -> pd.Series:
    return pd.to_numeric(series, errors="coerce")


def fallback_stop_words() -> set[str]:
    try:
        from nltk.corpus import stopwords

        return set(stopwords.words("english"))
    except Exception:
        try:
            import nltk

            nltk.download("stopwords", quiet=True)
            from nltk.corpus import stopwords

            return set(stopwords.words("english"))
        except Exception:
            from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS

            return set(ENGLISH_STOP_WORDS)


def decadal_bin(year: object) -> str:
    if pd.isna(year):
        return "unknown"
    try:
        year_value = int(float(year))
    except Exception:
        return "unknown"
    if year_value < 2000:
        return "pre-2000"
    if year_value < 2010:
        return "2000s"
    if year_value < 2020:
        return "2010s"
    return "2020s"


def score_bin(series: pd.Series) -> pd.Series:
    labels = ["low", "average", "good", "excellent"]
    try:
        return pd.qcut(series.rank(method="first"), q=4, labels=labels)
    except Exception:
        try:
            return pd.cut(series, bins=4, labels=labels, include_lowest=True)
        except Exception:
            return pd.Series(["average"] * len(series), index=series.index, dtype="object")


def mirror_if_exists(source: Path, target_names: Iterable[str] | None = None) -> None:
    if not source.exists():
        return
    ensure_results_dir()
    targets = target_names or [source.name]
    for target_name in targets:
        shutil.copy2(source, RESULTS_DIR / target_name)
