from __future__ import annotations

import subprocess
import sys

import pandas as pd

from pipeline_utils import save_dataframe


def main() -> None:
    input_path = sys.argv[1] if len(sys.argv) > 1 else "top_anime_dataset.csv"
    df = pd.read_csv(input_path)
    save_dataframe(df, "data_raw.csv")
    print(f"[ingest] Loaded {len(df):,} rows from {input_path}. Saved data_raw.csv", flush=True)
    subprocess.run([sys.executable, "preprocess.py", "data_raw.csv"], check=True)


if __name__ == "__main__":
    main()
