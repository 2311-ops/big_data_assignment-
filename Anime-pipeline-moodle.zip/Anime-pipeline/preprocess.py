from __future__ import annotations

import subprocess
import sys

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_selection import VarianceThreshold
from sklearn.preprocessing import MultiLabelBinarizer, StandardScaler

from pipeline_utils import (
    clean_text,
    decadal_bin,
    fallback_stop_words,
    normalize_bool,
    normalize_genre_list,
    safe_numeric,
    save_dataframe,
    score_bin,
)


def main() -> None:
    input_path = sys.argv[1] if len(sys.argv) > 1 else "data_raw.csv"
    df = pd.read_csv(input_path)
    df.columns = [str(col).strip() for col in df.columns]

    drop_cols = [col for col in ["mal_id", "url", "title_english"] if col in df.columns]
    df = df.drop(columns=drop_cols, errors="ignore")

    if "title" in df.columns:
        df = df.dropna(subset=["title"])
        df = df.drop_duplicates(subset=["title"], keep="first")

    if "genres" in df.columns:
        df["genres"] = df["genres"].fillna("").astype(str).map(
            lambda value: ", ".join(normalize_genre_list(value))
        )
        df = df[df["genres"].str.len() > 0].copy()

    if "synopsis" in df.columns:
        df["synopsis"] = df["synopsis"].astype(str)
        df.loc[df["synopsis"].str.strip().isin(["", "nan", "None"]), "synopsis"] = np.nan
        df = df.dropna(subset=["synopsis"])

    for column in ["episodes", "year"]:
        if column in df.columns:
            df[column] = safe_numeric(df[column])
            df[column] = df[column].fillna(df[column].median())

    if "score" in df.columns:
        df["score"] = safe_numeric(df["score"])
        df["score"] = df["score"].fillna(df["score"].mean())

    if "scored_by" in df.columns:
        df["scored_by"] = safe_numeric(df["scored_by"])
        df["scored_by"] = df["scored_by"].fillna(df["scored_by"].median())

    for column in ["type", "source", "status", "rating", "studios"]:
        if column in df.columns:
            df[column] = df[column].fillna("Unknown").astype(str).str.strip()
            df[column] = df[column].replace({"": "Unknown", "nan": "Unknown", "None": "Unknown"})

    if "airing" in df.columns:
        df["airing"] = df["airing"].map(normalize_bool)
    else:
        df["airing"] = False

    if "rank" in df.columns:
        df = df.drop(columns=["rank"])

    stop_words = fallback_stop_words()
    df["synopsis"] = df["synopsis"].map(lambda value: clean_text(value, stop_words))
    df = df[df["synopsis"].str.len() > 0].copy()

    df["score_bin"] = score_bin(df["score"])
    df["year_bin"] = df["year"].map(decadal_bin)

    categorical_cols = [col for col in ["type", "source", "rating", "status", "airing"] if col in df.columns]
    categorical_df = pd.get_dummies(
        df[categorical_cols].astype(str),
        prefix=categorical_cols,
        prefix_sep="__",
        dtype=int,
    )
    if not categorical_df.empty:
        selector = VarianceThreshold(threshold=0.01)
        selected = selector.fit_transform(categorical_df)
        kept_cols = categorical_df.columns[selector.get_support()].tolist()
        categorical_df = pd.DataFrame(selected, columns=kept_cols, index=df.index).astype(int)

    numeric_cols = [col for col in ["score", "episodes", "members", "favorites", "popularity", "year", "scored_by"] if col in df.columns]
    scaled_numeric_df = pd.DataFrame(index=df.index)
    if numeric_cols:
        scaler = StandardScaler()
        scaled = scaler.fit_transform(df[numeric_cols].astype(float))
        scaled_numeric_df = pd.DataFrame(
            scaled,
            columns=[f"scaled_{col}" for col in numeric_cols],
            index=df.index,
        )

    tfidf_df = pd.DataFrame(index=df.index)
    if df["synopsis"].str.strip().any():
        vectorizer = TfidfVectorizer(max_features=2000, ngram_range=(1, 2))
        tfidf_matrix = vectorizer.fit_transform(df["synopsis"])
        if tfidf_matrix.shape[1] > 0:
            mean = np.asarray(tfidf_matrix.mean(axis=0)).ravel()
            mean_sq = np.asarray(tfidf_matrix.power(2).mean(axis=0)).ravel()
            variances = mean_sq - np.square(mean)
            top_n = min(500, tfidf_matrix.shape[1])
            top_indices = np.argsort(variances)[::-1][:top_n]
            selected_matrix = tfidf_matrix[:, top_indices].toarray()
            tfidf_df = pd.DataFrame(
                selected_matrix,
                columns=[f"tfidf_{vectorizer.get_feature_names_out()[idx].replace(' ', '_')}" for idx in top_indices],
                index=df.index,
            )

    genre_df = pd.DataFrame(index=df.index)
    if "genres" in df.columns:
        mlb = MultiLabelBinarizer()
        genre_matrix = mlb.fit_transform(df["genres"].map(normalize_genre_list))
        genre_df = pd.DataFrame(
            genre_matrix,
            columns=[f"genre_{label}" for label in mlb.classes_],
            index=df.index,
        ).astype(int)

    output_df = df.copy()
    if not categorical_df.empty:
        output_df = pd.concat([output_df, categorical_df], axis=1)
    if not scaled_numeric_df.empty:
        output_df = pd.concat([output_df, scaled_numeric_df], axis=1)
    if not tfidf_df.empty:
        output_df = pd.concat([output_df, tfidf_df], axis=1)
    if not genre_df.empty:
        output_df = pd.concat([output_df, genre_df], axis=1)

    output_df = output_df.sort_index(axis=1)
    save_dataframe(output_df, "data_preprocessed.csv")
    print(
        f"[preprocess] Cleaned and transformed {len(output_df):,} rows. Saved data_preprocessed.csv",
        flush=True,
    )
    subprocess.run([sys.executable, "analytics.py", "data_preprocessed.csv"], check=True)


if __name__ == "__main__":
    main()
